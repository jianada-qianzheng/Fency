List of contents:


README.txt
3000shell_modified.c
3000shell.diff
3000shell

To compile the program and run it, please follow the instruction blow:

Compile command line:

	gcc 3000shell_modified.c


Then run program with the command line below:

	./a.out
